module.exports = {
  trailingComma: 'none',
  tabWidth: 2,
  printWidth: 110,
  semi: false,
  singleQuote: true
  //   bracketSameLine: true,
}
